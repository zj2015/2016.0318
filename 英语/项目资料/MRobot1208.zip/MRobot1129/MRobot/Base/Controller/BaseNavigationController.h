//
//  BaseNavigationController.h
//  BaseDemo
//
//  Created by 张娇娇 on 15/7/1.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@property(nonatomic,weak) UIViewController* currentShowVC;

@end
