//
//  ChooseIdentityViewController.h
//  MRobot
//
//  Created by BaiYu on 15/11/9.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseIdentityViewController : UIViewController

@end
