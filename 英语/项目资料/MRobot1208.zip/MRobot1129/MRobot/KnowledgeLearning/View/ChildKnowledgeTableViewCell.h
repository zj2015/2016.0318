//
//  ChildKnowledgeTableViewCell.h
//  MRobot
//
//  Created by BaiYu on 15/9/9.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildKnowledgeTableViewCell : UITableViewCell

@property(nonatomic,strong)UILabel *kChildLab;//子知识点名称
@end
