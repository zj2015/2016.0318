//
//  KSelectTableViewCell.h
//  MRobot
//
//  Created by BaiYu on 15/9/9.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KSelectTableViewCell : UITableViewCell

@property(nonatomic,strong)UILabel *kNameLab;//知识点名称
@end
