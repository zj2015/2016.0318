//
//  TopLevelKnowModel.m
//  MRobot
//
//  Created by mac on 15/8/21.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "TopLevelKnowModel.h"

@implementation TopLevelKnowModel

@synthesize resultArray;

- (instancetype)init
{
    self = [super init];
    if (self) {
        resultArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

@end
