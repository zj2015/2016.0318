//
//  TopLevelListModel.h
//  MRobot
//
//  Created by mac on 15/8/21.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  一级知识点列表
 */
@interface TopLevelListModel : BaseEntity

@property (copy, nonatomic) NSString *kId; //知识点Id

@property (copy, nonatomic) NSString *kName; //知识点名称

@property (copy, nonatomic) NSString *kContent; //知识点内容

@end
