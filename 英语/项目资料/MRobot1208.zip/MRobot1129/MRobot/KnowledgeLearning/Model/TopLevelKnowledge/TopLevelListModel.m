//
//  TopLevelListModel.m
//  MRobot
//
//  Created by mac on 15/8/21.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "TopLevelListModel.h"

@implementation TopLevelListModel

@synthesize kId;
@synthesize kName;
@synthesize kContent;

@end
