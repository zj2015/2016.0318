//
//  ChildLevelListModel.m
//  MRobot
//
//  Created by mac on 15/8/21.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "ChildLevelListModel.h"

@implementation ChildLevelListModel

@synthesize kId;
@synthesize kName;
@synthesize kContent;
//@synthesize hasViewed;
//@synthesize remainAmount;

@end
