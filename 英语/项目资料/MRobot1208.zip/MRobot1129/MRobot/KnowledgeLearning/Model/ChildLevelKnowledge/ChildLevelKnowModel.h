//
//  ChildLevelKnowModel.h
//  MRobot
//
//  Created by mac on 15/8/21.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  子级知识点列表
 */
@interface ChildLevelKnowModel : BaseEntity

@property (strong, nonatomic) NSMutableArray *resultArray;

@end
