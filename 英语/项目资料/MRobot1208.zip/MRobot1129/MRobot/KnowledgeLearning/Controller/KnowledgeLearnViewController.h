//
//  KnowledgeLearnViewController.h
//  MRobot
//
//  Created by mac on 15/8/19.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseViewController.h"
#import "KnowledgeSelectViewController.h"

@interface KnowledgeLearnViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate,PassSelestRowDelegate>
{
    NSArray *kDataArr;
    NSMutableArray *kNameArr;
    
    NSInteger selectRow;
}
@property (strong, nonatomic) UITableView *myTableView;

@end
