#import <UIKit/UIKit.h>
#import "DWSDK.h"
#import "UMSocialControllerService.h"
#import "UMSocialShakeService.h"
#import "MKActionView.h"

#define kTagShareEdit 101
#define kTagSharePost 102
@interface DWCustomPlayerViewController : BaseViewController<UIActionSheetDelegate,UMSocialUIDelegate,
UMSocialShakeDelegate>
{
    UIView *bgView;
    UIView *alertView;
}
@property (copy, nonatomic)NSString *videoId;
@property (copy, nonatomic)NSString *videoTitle;
@property (copy, nonatomic)NSString *videoLocalPath;
@property (copy, nonatomic)NSString *imgUrlstring;
@property (copy, nonatomic)NSString *videoURL;
@end

