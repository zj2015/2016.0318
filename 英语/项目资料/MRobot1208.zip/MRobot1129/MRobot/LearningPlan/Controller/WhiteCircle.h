//
//  WhiteCircle.h
//  MRobot
//
//  Created by sdfsdf on 15/11/19.
//  Copyright © 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WhiteCircle : UIView

@end
