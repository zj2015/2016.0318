//
//  TrainShareViewController.h
//  MRobot
//
//  Created by mac on 15/8/22.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseViewController.h"
#import "UMSocialControllerService.h"
#import "UMSocialShakeService.h"

@interface TrainShareViewController : BaseViewController<UIActionSheetDelegate,UMSocialUIDelegate,
UMSocialShakeDelegate>

@property (strong, nonatomic) NSString *score;
@property (strong, nonatomic) NSString *highScore;
@property (strong, nonatomic) NSString *beatPercent;

@end
