//
//  TrainResultTwoViewController.h
//  MRobot
//
//  Created by mac on 15/8/22.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseViewController.h"
#import "SubmitQuestionModel.h"
#import "QuestionDataModel.h"
#import "SubmitByPaperModel.h"
@interface TrainResultTwoViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) SubmitQuestionModel *submitModel;
@property (strong, nonatomic) SubmitByPaperModel *paperModel;
@property(nonatomic,strong)UITableView * myTableView;
@property (strong, nonatomic) NSArray *arr;
@property (strong, nonatomic) NSArray *arrRight;
@property (copy, nonatomic) NSString *kId;
@property (copy, nonatomic) NSString *kName;

@property (strong, nonatomic) NSArray *badArray;

@property (strong, nonatomic) NSArray *answerArray;

@property (strong, nonatomic) QuestionDataModel *questionModel;

@property (assign, nonatomic) int fromType;// 0 知识点学习的知识点题目列  1:我的重新训练



@end
