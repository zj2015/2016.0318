//
//  PicBrowseViewController.h
//  Elibrary
//
//  Created by zjb on 15/6/11.
//  Copyright (c) 2015年 zjb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VIPhotoView.h"
@interface PicBrowseViewController : UIViewController{
    VIPhotoView *photoView;
}
@property(nonatomic,strong)UIImage *image;
@end
