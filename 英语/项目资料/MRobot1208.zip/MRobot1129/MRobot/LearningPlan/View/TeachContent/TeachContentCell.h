     //
//  TeachContentCell.h
//  ERobot
//
//  Created by 郭东丽 on 15/7/2.
//  Copyright (c) 2015年 BaiYu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeachContentCell : UITableViewCell

@property (nonatomic,strong)UILabel * leftLabel;//The course credits列表左边的文字；
@property (nonatomic,strong)UILabel * teachContentLabel;//The course credits文字；
@property (nonatomic,strong)UILabel *lineLab;

@end
