//
//  CustomAlertView.h
//  MRobot
//
//  Created by BaiYu on 15/8/28.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomAlertView : UIView

@property (strong , nonatomic) UIButton *continueBtn;
@property (strong , nonatomic) UIButton *cancleBtn;
@end
