//
//  SubmitBadViewController.h
//  MRobot
//
//  Created by mac on 15/8/24.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TrainResultViewController;
#define ROWHEIGHT 120

@interface SubmitBadViewController : UIViewController

@property (strong, nonatomic) UIView *bgView;

@property (strong, nonatomic) UILabel *wrongLabel;

@property (strong, nonatomic) UIImageView *lineView;

@property (strong, nonatomic) TrainResultViewController *trainResultVC;

@property (assign, nonatomic) NSInteger titleCount;

@property (strong, nonatomic) NSArray *dataArr;

@end
