//
//  CommonSkillModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "CommonSkillModel.h"

@implementation CommonSkillModel

@synthesize commonSkillListArr;

- (instancetype)init
{
    self = [super init];
    if (self) {
        commonSkillListArr = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}

@end
