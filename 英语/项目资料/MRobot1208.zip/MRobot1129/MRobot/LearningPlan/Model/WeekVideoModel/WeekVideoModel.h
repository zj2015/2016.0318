//
//  WeekVideoModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  VideosModel
 */
@interface WeekVideoModel : BaseEntity

@property (strong, nonatomic) NSMutableArray * kVideoListArr;//视频列表


@property (strong, nonatomic) NSMutableArray * sVideoListArr;

@end
