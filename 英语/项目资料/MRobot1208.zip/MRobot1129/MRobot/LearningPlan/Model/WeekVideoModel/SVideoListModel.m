//
//  SVideoListModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "SVideoListModel.h"

@implementation SVideoListModel

@synthesize sId;
@synthesize sName;
@synthesize sVideoCCId;
@synthesize sVideoCoverUrl;
@synthesize sVideoUrl;

@end
