//
//  CVideoListModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "CVideoListModel.h"

@implementation CVideoListModel

@synthesize cVideoCCId;
@synthesize cVideoCoverUrl;
@synthesize cVideoUrl;

@end
