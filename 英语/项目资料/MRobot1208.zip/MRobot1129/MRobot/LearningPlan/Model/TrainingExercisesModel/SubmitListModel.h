//
//  SubmitListModel.h
//  ERobot
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 BaiYu. All rights reserved.
//

#import "BaseEntity.h"

@interface SubmitListModel : BaseEntity

@property (copy, nonatomic) NSString *kId;

@property (copy, nonatomic) NSString *kName;

@property (copy, nonatomic) NSString *kContent;

@property (strong, nonatomic) NSMutableArray *wrongQIdList;

@end
