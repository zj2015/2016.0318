//
//  SubmitListModel.m
//  ERobot
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 BaiYu. All rights reserved.
//

#import "SubmitListModel.h"

@implementation SubmitListModel
@synthesize kId;
@synthesize kContent;
@synthesize kName;
@synthesize wrongQIdList;

-(id)init{
    if (self = [super init]) {
        wrongQIdList = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return self;
}
@end
