//
//  FillBlanksModel.m
//  ERobot
//
//  Created by mac on 15/7/2.
//  Copyright (c) 2015年 BaiYu. All rights reserved.
//

#import "FillBlanksModel.h"

@implementation FillBlanksModel

@synthesize optionId;
@synthesize optionContent;
@synthesize optionPicUrl;
@synthesize isAnswer;
@synthesize myOption;

@end
