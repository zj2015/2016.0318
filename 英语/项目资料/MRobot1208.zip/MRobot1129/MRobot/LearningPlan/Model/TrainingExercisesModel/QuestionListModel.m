//
//  QuestionListModel.m
//  ERobot
//
//  Created by mac on 15/7/2.
//  Copyright (c) 2015年 BaiYu. All rights reserved.
//

#import "QuestionListModel.h"

@implementation QuestionListModel

@synthesize qId;
@synthesize qContent;
@synthesize qContentPicUrl;
@synthesize answerAnalysis;
@synthesize answerVideoAnalysis;
@synthesize options;
@synthesize myOptionId;

-(id)init{
    if (self = [super init]) {
        options = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return self;
}
@end
