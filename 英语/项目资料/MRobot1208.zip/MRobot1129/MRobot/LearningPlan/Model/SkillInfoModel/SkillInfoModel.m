//
//  SkillInfoModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "SkillInfoModel.h"

@implementation SkillInfoModel

@synthesize sId;
@synthesize sName;
@synthesize mainVideoCCId;
@synthesize mainVideoCoverUrl;
@synthesize mainVideoUrl;

@end
