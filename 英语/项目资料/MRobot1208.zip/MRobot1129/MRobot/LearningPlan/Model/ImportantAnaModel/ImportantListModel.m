//
//  ImportantListModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "ImportantListModel.h"

@implementation ImportantListModel

@synthesize sId;
@synthesize sName;
@synthesize videoCCId;
@synthesize videoCoverUrl;
@synthesize videoName;
@synthesize videoUrl;

@end
