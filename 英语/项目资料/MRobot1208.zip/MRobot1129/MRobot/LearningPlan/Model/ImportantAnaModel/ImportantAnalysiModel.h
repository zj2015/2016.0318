//
//  ImportantAnalysiModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  重点解析-综合训练
 */
@interface ImportantAnalysiModel : BaseEntity

@property (strong, nonatomic) NSMutableArray * skillListArray;

@end
