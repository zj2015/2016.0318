//
//  SkillDataModel.m
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "SkillDataModel.h"

@implementation SkillDataModel

@synthesize skillListArr;

- (instancetype)init
{
    self = [super init];
    if (self) {
        skillListArr = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return self;
}

@end
