//
//  SkillDataModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  技巧训练-综合训练
 */
@interface SkillDataModel : BaseEntity

@property (strong, nonatomic) NSMutableArray * skillListArr;

@end
