//
//  AnalyticalKnowledgeModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  AnalysisModel
 */
@interface AnalyticalKnowledgeModel : BaseEntity

@property (strong, nonatomic) NSMutableArray * analyticalKnowledgeArr;//analyticalKnowledge数组

@end
