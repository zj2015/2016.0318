//
//  KnowledgeVideoModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  知识点视频列表Model
 */
@interface KnowledgeVideoModel : BaseEntity

@property (strong, nonatomic) NSMutableArray *resultArray;

@end
