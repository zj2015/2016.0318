//
//  SubmitBySkillModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  提交答案-综合训练技巧训练
 *  提交答案-题型选择
 */
@interface SubmitBySkillModel : BaseEntity

@property (strong, nonatomic) NSMutableArray *resultList;

@end
