//
//  ResultListModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  提交答案-教材强化习题训练
 */
@interface ResultListModel : BaseEntity

@property (copy, nonatomic) NSString * kId; //知识点ID

@property (copy, nonatomic) NSString * kName; //知识点名称

@property (copy, nonatomic) NSString *kContent; //知识点内容

@property (strong, nonatomic) NSMutableArray * wrongQIdList;// 错题ID集合

@end
