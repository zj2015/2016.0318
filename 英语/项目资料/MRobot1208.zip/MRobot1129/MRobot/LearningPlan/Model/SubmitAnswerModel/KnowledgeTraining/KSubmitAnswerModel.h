//
//  KSubmitAnswerModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  提交答案-知识点习题训练
 */
@interface KSubmitAnswerModel : BaseEntity

@property (copy, nonatomic) NSString * score; //得分

@property (copy, nonatomic) NSString * highestScore; //历史最高分

@property (copy, nonatomic) NSString * beatPercent; //击败百分比

@property (strong, nonatomic) NSMutableArray *well;

@property (strong, nonatomic) NSMutableArray *bad;

@property (strong, nonatomic) NSMutableArray *wrongQIdList;

@end
