//
//  ExamProModel.h
//  MRobot
//
//  Created by mac on 15/8/20.
//  Copyright (c) 2015年 silysolong. All rights reserved.
//

#import "BaseEntity.h"
/**
 *  学习进度Model
 */
@interface ExamProModel : BaseEntity

@property (strong, nonatomic) NSMutableArray * examProListArr;//单元列表

@end
