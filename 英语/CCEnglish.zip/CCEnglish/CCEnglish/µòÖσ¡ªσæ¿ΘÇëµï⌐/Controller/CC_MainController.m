//
//  CC_MainController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_MainController.h"
#import "CC_PlanStudyController.h"
#import "MyClassViewController.h"
#import "CC_PleasesStudyContoller.h"
#import "CC_BottomView.h"

@interface CC_MainController ()<CC_BottomViewDelegate>

@end

@implementation CC_MainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self addchildrenControllers];
    
    [self addselectToolBar];
    
    
}


- (void)addchildrenControllers
{
    CC_PlanStudyController *planVC = [[CC_PlanStudyController alloc]init];
    
    [self addChildViewController:planVC];
    
    MyClassViewController *classVC = [[MyClassViewController alloc]init];
    [self addChildViewController:classVC];
    
    
    CC_PleasesStudyContoller *pleaseVC = [[CC_PleasesStudyContoller alloc]init];
    [self addChildViewController:pleaseVC];

}

- (void)addselectToolBar
{
    
    CC_BottomView *ToolBar = [[CC_BottomView alloc]initWithFrame:CGRectMake(0, kScreenH- 45, kScreenW, 45)];
    [self.view addSubview:ToolBar];
    ToolBar.delegate = self;
}


- (void)BottomView:(CC_BottomView *)bottomView andSelectIndex:(NSInteger)selectIndex
{
    
}
@end
