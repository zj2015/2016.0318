//
//  CC_BottomView.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/12.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_BottomView.h"

@interface CC_BottomView()
{
    NSMutableArray *_btnArray;
}
@end
@implementation CC_BottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
        _btnArray = [NSMutableArray array];
        
    }
    return self;
}

- (void)setupsubViews
{
    UIButton *studybtn = [[UIButton alloc]init];
    [studybtn setImage:[UIImage imageNamed:@"studyplannomal"] forState:UIControlStateNormal];
    [studybtn setImage:[UIImage imageNamed:@"studyplanselect"] forState:UIControlStateSelected];
    [self addSubview:studybtn];
    [_btnArray addObject:studybtn];

    
    UIButton *myclassbtn = [[UIButton alloc]init];
    [myclassbtn setImage:[UIImage imageNamed:@"banjinomal"] forState:UIControlStateNormal];
    [myclassbtn setImage:[UIImage imageNamed:@"banjinomalselect"] forState:UIControlStateSelected];
    [self addSubview:myclassbtn];
    [_btnArray addObject:myclassbtn];

    
    UIButton *pleasStudyBtn = [[UIButton alloc]init];
    [pleasStudyBtn setImage:[UIImage imageNamed:@"shuiyixuenomal"] forState:UIControlStateNormal];
    [pleasStudyBtn setImage:[UIImage imageNamed:@"shuiyixueselect"] forState:UIControlStateSelected];
    [self addSubview:pleasStudyBtn];
    [_btnArray addObject:pleasStudyBtn];

}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat btnw = 85;
    CGFloat margin = (kScreenW-85*3)/4;
    for (int i=0; i<_btnArray.count; i++) {
        UIButton *btn = _btnArray[i];
        btn.frame = CGRectMake(margin*(i+1)+btnw*i, 0, btnw, self.height);
    }
}
@end
