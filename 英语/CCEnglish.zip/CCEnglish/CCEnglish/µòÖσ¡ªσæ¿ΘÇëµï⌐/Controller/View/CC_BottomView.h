//
//  CC_BottomView.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/12.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CC_BottomView;

@protocol CC_BottomViewDelegate <NSObject>

- (void)BottomView:(CC_BottomView *)bottomView andSelectIndex:(NSInteger)selectIndex;

@end

@interface CC_BottomView : UIView

@property (nonatomic, weak) id <CC_BottomViewDelegate> delegate;

@end
