//
//  URLConfigs.h
//  CCEnglish
//
//  Created by AA on 16/3/9.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#ifndef URLConfigs_h
#define URLConfigs_h
#import <Foundation/Foundation.h>


// MARK: url host config

/*-----------------------------*/
/*!
 @abstract 启用测试线的host等配置。
 */
#define Debug_Version

/*!
 @abstract 启用正式线的host等配置。
 */
//#define Release_Version
/*-----------------------------*/


/*-----------------------------------------------*/
#ifdef Debug_Version

#define URL_API_HOST @"http://139.196.192.24:903/api"
#define Appsectet @"i1p2h3"
#define appid @"iphone"
#define SMSappkey @"e7ea2ed7925c"
#define SMSsecrect @"cf5cb9937736e7455503f7bae1ca2994"

#endif

#ifdef Release_Version

#define URL_API_HOST @"http://139.196.192.24:903/api"
#define Appsectet @"i1p2h3"
#define appid @"iphone"

#define SMSappkey @"e7ea2ed7925c"
#define SMSsecrect @"cf5cb9937736e7455503f7bae1ca2994"



#endif
/*---------------------------------------------*/


// MARK: generate url

NS_ASSUME_NONNULL_BEGIN

/*!
 @abstract 根据接口路径以及API_HOST生成接口地址.
 @param path 接口路径。
 @return 接口地址.
 */
static inline NSString * API_URL(NSString *path) {
    return [NSString stringWithFormat:@"%@%@", URL_API_HOST, path];
}

NS_ASSUME_NONNULL_END


#endif /* URLConfigs_h */
