//
//  AppDelegate.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/5.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

