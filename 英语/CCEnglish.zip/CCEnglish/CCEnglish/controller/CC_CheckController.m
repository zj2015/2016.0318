//
//  CC_CheckController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_CheckController.h"

@interface CC_CheckController ()

@end

@implementation CC_CheckController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

}


@end
