//
//  CC_StudyCountController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_StudyCountController.h"

@interface CC_StudyCountController ()

@end

@implementation CC_StudyCountController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

}


@end
