//
//  CC_StudyPlanController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_StudyPlanController.h"

@interface CC_StudyPlanController ()

@end

@implementation CC_StudyPlanController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

}



@end
