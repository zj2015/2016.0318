//
//  CC_ErrorController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_ErrorController.h"

@interface CC_ErrorController ()

@end

@implementation CC_ErrorController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

}



@end
