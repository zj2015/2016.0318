//
//  ViewController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/5.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_SliderMainController.h"
#import "CC_SliderView.h"
#import "CC_NavigationBar.h"
#import "UIBarButtonItem+extension.h"

#import "CC_MainController.h"
#import "CC_StudyCountController.h"
#import "CC_StudyPlanController.h"
#import "CC_ErrorController.h"
#import "CC_CancelController.h"
#import "CC_CheckController.h"
#import "CC_PersonController.h"
#import "CC_HelpController.h"
#import "CC_ErrorBookController.h"

@interface CC_SliderMainController ()<CC_SliderViewDelegate>

@property (nonatomic, strong) UIViewController *displayVC;
@property (nonatomic, weak) CC_SliderView *sliderView;

@end

@implementation CC_SliderMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *backImageView = [[UIImageView alloc]init];
    backImageView.frame = CGRectMake(0, 0, kScreenW, kScreenH);
    backImageView.userInteractionEnabled = YES;
    backImageView.image = [UIImage imageNamed:@"backView"];
    [self.view addSubview:backImageView];

    
    //添加侧边栏
    self.view.backgroundColor = [UIColor yellowColor];
    CC_SliderView *slider = [[CC_SliderView alloc]initWithFrame:self.view.bounds];
    slider.x = -self.view.frame.size.width*0.25;
    self.sliderView = slider;
    self.sliderView.delegate = self;
    [self.view addSubview:slider];
    
    [self addRecognizer];

    [self addchildControllers];
    
    [self sliderDidselected:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    
    
}

- (void)addchildControllers
{
    
    //主页面
    CC_MainController *mainVC = [[CC_MainController alloc]init];
    [self addchildVC:mainVC andTitle:@"教学周选择" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    mainVC.view.backgroundColor = [UIColor yellowColor];
    
    
    //学习规划
    CC_StudyPlanController *planVC = [[CC_StudyPlanController alloc]init];
    [self addchildVC:planVC andTitle:@"学习规划分析" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    
    //易错知识点
    CC_StudyCountController *studyCountVC = [[CC_StudyCountController alloc]init];
    [self addchildVC:studyCountVC andTitle:@"我的易错知识点" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];

    //我的错题集
    CC_ErrorController *errorVC = [[CC_ErrorController alloc]init];
    [self addchildVC:errorVC andTitle:@"我的错题库" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    
    //成绩查询
    CC_ErrorBookController *errorBookVC = [[CC_ErrorBookController alloc]init];
    [self addchildVC:errorBookVC andTitle:@"成绩查询" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    
    
    //个人中心
    CC_CheckController *checkVC = [[CC_CheckController alloc]init];
    [self addchildVC:checkVC andTitle:@"个人中心" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    
    
    //帮助
    CC_PersonController *personVC = [[CC_PersonController alloc]init];
    [self addchildVC:personVC andTitle:@"帮助" andleftItemImage:nil andrightItem:nil andNavigationBar:@"111"];
    
    //退出登录
    CC_CancelController *cancelVC = [[CC_CancelController alloc]init];
    [self addchildVC:cancelVC andTitle:@"" andleftItemImage:nil andrightItem:nil andNavigationBar:nil];

}


- (void)addchildVC:(UIViewController *)childVC andTitle:(NSString *)title andleftItemImage:(NSString *)leftImage andrightItem:(NSString *)rightImage andNavigationBar:(NSString *)barImage
{
    UINavigationController *nav = nil;
    childVC.title = title;
    
    if (barImage) {
        nav = [[UINavigationController alloc]initWithRootViewController:childVC];
        UINavigationBar *appearance = [UINavigationBar appearance];
        [appearance setBackgroundImage:[UIImage imageNamed:barImage] forBarMetrics:UIBarMetricsDefault];
        appearance.backgroundColor = [UIColor redColor];
        [nav setValue:[[CC_NavigationBar alloc] init] forKeyPath:@"navigationBar"];
        
        [self addChildViewController:nav];
        
        if (leftImage) nav.navigationItem.leftBarButtonItem  = [UIBarButtonItem itemWithImageName:leftImage target:self action:@selector(leftMenuClick)];

         if (rightImage) nav.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithImageName:rightImage target:self action:@selector(rightMenuClick)];
        
        
    }else{
    
//        if ([childVC isKindOfClass:[CC_MainController class]]) {
            [self.view addSubview:childVC.view];
            childVC.view.frame = self.view.bounds;
            
            self.displayVC = childVC;
//        }

        [self addChildViewController:childVC];
    
    }
    
}

//添加手势
-(void)addRecognizer{
    //    添加拖拽
    UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(didPanEvent:)];
    
    [self.view addGestureRecognizer:pan];
}


//实现拖拽
-(void)didPanEvent:(UIPanGestureRecognizer *)recognizer{
    
    
    // 1. 获取手指拖拽的时候, 平移的值
    CGPoint translation = [recognizer translationInView:[self.view.subviews objectAtIndex:2]];
    
    // 2. 让当前控件做响应的平移
    [self.view.subviews objectAtIndex:2].transform = CGAffineTransformTranslate([self.view.subviews objectAtIndex:2].transform, translation.x, 0);
    
    [self.view.subviews objectAtIndex:1].ttx=[self.view.subviews objectAtIndex:2].ttx/3;
    
    // 3. 每次平移手势识别完毕后, 让平移的值不要累加
    [recognizer setTranslation:CGPointZero inView:[self.view.subviews objectAtIndex:2]];
    
    //获取最右边范围
    CGAffineTransform  rightScopeTransform=CGAffineTransformTranslate(self.view.transform,[UIScreen mainScreen].bounds.size.width*0.75, 0);
    
    //    当移动到右边极限时
    if ([self.view.subviews objectAtIndex:2].transform.tx>rightScopeTransform.tx) {
        
        //        限制最右边的范围
        [self.view.subviews objectAtIndex:2].transform=rightScopeTransform;
        //        限制透明view最右边的范围
        [self.view.subviews objectAtIndex:1].ttx=[self.view.subviews objectAtIndex:2].ttx/3;
        
        //        当移动到左边极限时
    }else if ([self.view.subviews objectAtIndex:2].transform.tx<0.0){
        
        //        限制最左边的范围
        [self.view.subviews objectAtIndex:2].transform=CGAffineTransformTranslate(self.view.transform,0, 0);
        //    限制透明view最左边的范围
        [self.view.subviews objectAtIndex:1].ttx=[self.view.subviews objectAtIndex:2].ttx/3;
        
    }
    //    当托拽手势结束时执行
    if (recognizer.state == UIGestureRecognizerStateEnded)
    {
        [UIView animateWithDuration:0.2 animations:^{
            
            if ([self.view.subviews objectAtIndex:2].x >[UIScreen mainScreen].bounds.size.width*0.5) {
                
                [self.view.subviews objectAtIndex:2].transform=rightScopeTransform;
                
                [self.view.subviews objectAtIndex:1].ttx=[self.view.subviews objectAtIndex:2].ttx/3;
                
            }else{
                
                [self.view.subviews objectAtIndex:2].transform = CGAffineTransformIdentity;
                
                [self.view.subviews objectAtIndex:1].ttx=[self.view.subviews objectAtIndex:2].ttx/3;
            }
        }];
    }
    
}


- (void)leftMenuClick
{
    
}


- (void)rightMenuClick
{

}


#pragma mark - sliderDelegate
- (void)sliderDidselected:(NSIndexPath *)selectedIndex
{
    
    UIViewController *currentVC = self.childViewControllers[selectedIndex.row];
    if (self.displayVC == currentVC) {
        [self identity];
        return;
    }
    currentVC.view.transform = self.displayVC.view.transform;
    currentVC.view.frame = self.displayVC.view.frame;
    [self.view addSubview:currentVC.view];
    [self.displayVC.view removeFromSuperview];
    self.displayVC = currentVC;
    [self identity];
}

- (void)identity
{
    [UIView animateWithDuration:.25 animations:^{
        
        self.displayVC.view.transform = CGAffineTransformIdentity;
        
    }];


}
@end
