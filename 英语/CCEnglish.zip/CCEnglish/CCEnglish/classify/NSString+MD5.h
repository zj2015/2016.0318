//
//  NSString+MD5.h
//  KDBCommon
//
//  Created by zhangshiming on 15/5/16.
//  Copyright (c) 2015年 zhangshiming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)MD5;

@end
