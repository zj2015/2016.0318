//
//  CC_SliderCell.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_SliderCell.h"

@implementation CC_SliderCell

- (void)setFrame:(CGRect)frame
{
    frame = CGRectMake(50, frame.origin.y, frame.size.width, frame.size.height);
    [super setFrame:frame];
}
@end
