//
//  CC_SliderView.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_SliderView.h"
#import "CC_SliderCell.h"

@interface CC_SliderView()<UITableViewDataSource, UITableViewDelegate>
{
    UIImageView *_headImage;
    UILabel *_nameLb;

}

@property (nonatomic, strong) NSArray *itemArray;

@end

@implementation CC_SliderView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self setupheadView];
    }
    
    return self;
}


- (void)setupheadView
{
     
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.frame = CGRectMake(32, 46, 53, 53);
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.image = [UIImage imageNamed:@"0"];
    imageView.clipsToBounds = YES;
    imageView.layer.cornerRadius =imageView.bounds.size.height * 0.5;
    imageView.backgroundColor = [UIColor yellowColor];
    _headImage = imageView;
    [self addSubview:imageView];
    
    _nameLb = [[UILabel alloc]init];
    _nameLb.textColor = [UIColor colorWithHex:@"#538802"];
    _nameLb.font = [UIFont systemFontOfSize:17];
    _nameLb.text = @"小明";
    _nameLb.frame = CGRectMake(CGRectGetMaxX(imageView.frame)+15, imageView.y +16, 100, 20);
    [self addSubview:_nameLb];
    
    UITableView *tableView = [[UITableView alloc]init];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.backgroundColor = [UIColor clearColor];
    CGFloat y = CGRectGetMaxY(imageView.frame)+20;
    tableView.frame = CGRectMake(0, y, kScreenW, kScreenH- y);
    [self addSubview:tableView];
    
    
    
}



- (void)setDcit:(NSDictionary *)dcit
{


}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 8;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CC_SliderCell *cell=[[CC_SliderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
    if (indexPath.row==0) {
        cell.imageView.image=[UIImage imageNamed:@"2"];
        cell.textLabel.text=@"学习规划";
    }else if (indexPath.row==1){
        cell.imageView.image=[UIImage imageNamed:@"2"];
        cell.textLabel.text=@"学习统计";
    }else if (indexPath.row==2){
        cell.imageView.image=[UIImage imageNamed:@"3"];
        cell.textLabel.text=@"易错知识点";
    }else if (indexPath.row==3){
        cell.imageView.image=[UIImage imageNamed:@"4"];
        cell.textLabel.text=@"我的错题集";
    }else if (indexPath.row==4){
        cell.imageView.image=[UIImage imageNamed:@"5"];
        cell.textLabel.text=@"成绩查询";
    }else if (indexPath.row==5){
        cell.imageView.image=[UIImage imageNamed:@"5"];
        cell.textLabel.text=@"个人中心";
    }else if (indexPath.row==6){
        cell.imageView.image=[UIImage imageNamed:@"5"];
        cell.textLabel.text=@"帮助";
    }else{
        cell.imageView.image=[UIImage imageNamed:@"8"];
        cell.textLabel.text=@"退出登录";
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  50;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //拿到当前控制器
    if ([self.delegate respondsToSelector:@selector(sliderDidselected:)]) {
        
        [self.delegate sliderDidselected:indexPath];
    }
    
}
@end
