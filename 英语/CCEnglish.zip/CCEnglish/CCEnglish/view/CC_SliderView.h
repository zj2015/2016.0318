//
//  CC_SliderView.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/6.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CC_SliderViewDelegate <NSObject>

- (void)sliderDidselected:(NSIndexPath *)selectedIndex;

@end

@interface CC_SliderView : UIView

@property (nonatomic, weak) id<CC_SliderViewDelegate> delegate;
@property (nonatomic, strong) NSDictionary *dcit;

@end
