//
//  CC_SeversRequset.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_SeversRequset.h"
#import "NSString+Hash.h"
#import "CC_CountTool.h"

@interface CC_SeversRequset()

@property (nonatomic, strong) AFHTTPRequestOperationManager *manager;


@end

@implementation CC_SeversRequset


- (AFHTTPRequestOperationManager *)manager
{
    if (!_manager) {
        _manager = [AFHTTPRequestOperationManager manager];
        _manager.requestSerializer= [AFHTTPRequestSerializer serializer];
        _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        _manager.requestSerializer.timeoutInterval = 60;
//       _manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
//        [_manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
//        [_manager.requestSerializer setValue:@"text/html; charset=utf-8" forHTTPHeaderField:@"Content-Type"];

    }
    return _manager;
}

- (void)requesetWithAccess_tokenAndsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    int timestamp = [[NSDate date] timeIntervalSince1970];//时间
    int nonce = arc4random() % 9000 + 1000;
    NSLog(@",,,,%@",Appsectet);
    NSString *sign = [NSString stringWithFormat:@"%@%d%d",Appsectet,timestamp,nonce];//签名
    sign = [sign md5String];
    dict[@"timestamp"] = [NSString stringWithFormat:@"%d",timestamp];
    dict[@"nonce"] = [NSString stringWithFormat:@"%d",nonce];
    dict[@"appid"] = appid;
    dict[@"signature"] = sign;
    NSString *tokenURL = API_URL(@"/Token/Access_Token");
    
    [self GETRequsetWithURL:tokenURL andParams:dict andClass:nil withsuccess:succussBlock andfailBlock:errorblock];
  
}


- (void)RequsetWithZone:(NSString *)type andRegion:(NSString*)Region  Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{
    NSString *zoneURL = API_URL(@"/Region/List");
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"Type"] = type;
    if (Region) {
        dict[@"RegionId"] = Region;
    }
    [self GETRequsetWithURL:zoneURL andParams:dict andClass:nil withsuccess:succussBlock andfailBlock:errorblock];
}

- (void)RequestWithLogin:(NSString *)UserType andUserName:(NSString *)UserName andMobile:(NSString *)Mobile andPassword:(NSString *)Password Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{
    NSString *loginURL = API_URL(@"/Account/Login");
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[@"UserType"] = @"Student-";
    dict[@"UserName"] = UserName.MD5;
    dict[@"Mobile"] = Mobile;
    dict[@"Password"] = Password.MD5;
    [self POSTRequsetWithURL:loginURL andParams:dict andClass:nil withsuccess:succussBlock andfailBlock:errorblock];

}

- (void)RequsetWithRegister:(NSString *)UserName andMobile:(NSString *)Mobile andPassWord:(NSString *)Password andRegionCode:(NSString *)RegionCode andReferrer:(NSString *)Referrer Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{
    NSString *registerURL = API_URL(@"/Account/Register");
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:UserName forKey:@"UserName"];
    [dict setObject:Mobile forKey:@"Mobile"];
    [dict setObject:[Password md5String] forKey:@"Password"];
    [dict setObject:RegionCode forKey:@"RegionCode"];
    if (Referrer.length>0) {
        [dict setObject:Referrer forKey:@"Referrer"];
    }
    [self POSTRequsetWithURL:registerURL andParams:dict andClass:nil withsuccess:succussBlock andfailBlock:errorblock];
}


/**
 *  @author 张杰, 16-03-08 20:03:47
 *
 *  数据请求公共接口
 *
 *  @param URL          url路径
 *  @param parmas       参数字典
 *  @param class        字典转成的模型
 *  @param succussBlock 成功回调
 *  @param errorblock   失败回调
 *
 *  @return 返回opretaion
 */
- (id)GETRequsetWithURL:(NSString *)URL andParams:(id)parmas andClass:(Class)class withsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{

    [self.manager GET:URL parameters:parmas success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
        NSLog(@"%s - response: %@", __func__, dict);
        NSInteger value = [dict[@"code"] integerValue];
        if (value !=0 ) {
            [MBProgressHUD showError:dict[@"message"]];
        }
        succussBlock(dict);
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%s - error: %@", __func__, error);
        
        [MBProgressHUD showError:@"请求失败"];
        errorblock(error);
    }];
    
     return nil;
}


- (id)POSTRequsetWithURL:(NSString *)URL andParams:(id)parmas andClass:(Class)class withsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock
{
    
    [coutTool getAccess_tokenfinishBlock:^(NSString *token) {
        if (token) {
            [parmas setObject:token forKey:@"access_token"];
            [self.manager.requestSerializer setValue:token forHTTPHeaderField:@"access_token"];
        }
        
        [self.manager POST:URL parameters:parmas success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil];
            NSLog(@"%s - response: %@", __func__, dict);
            NSInteger value = [dict[@"code"] integerValue];
            if (value !=0 ) {
                [MBProgressHUD showError:dict[@"message"]];
            }
            succussBlock(dict);
            
        } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
            NSLog(@"%s - error: %@", __func__, error);
            NSLog(@"%s - error: %@", __func__, [[NSString alloc] initWithData:error.userInfo[@"com.alamofire.serialization.response.error.data"] encoding:NSUTF8StringEncoding]);

            [MBProgressHUD showError:@"请求失败"];
            NSLog(@"%@",self.manager.requestSerializer.HTTPRequestHeaders);
            errorblock(error);
        }];

        
    }];
    
    return nil;
}




@end
