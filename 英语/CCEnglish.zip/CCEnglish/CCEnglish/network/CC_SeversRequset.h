//
//  CC_SeversRequset.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^responseSuccessBlock)(id result);
typedef void(^responseErrorBlock)(id error);

#define CC_Requset [[CC_SeversRequset alloc]init]
@interface CC_SeversRequset : NSObject

//获取Access_token
- (void)requesetWithAccess_tokenAndsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock;

//登录
/**
 *  @author 张杰, 16-03-12 00:03:11
 *
 *  登录
 *
 *  @param UserType     用户类型
 *  @param UserName     用户名
 *  @param Mobile       手机号
 *  @param Password     密码
 *  @param succussBlock 登录成功
 *  @param errorblock   登录失败
 */
- (void)RequestWithLogin:(NSString *)UserType andUserName:(NSString *)UserName andMobile:(NSString *)Mobile andPassword:(NSString *)Password Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock;


//注册
/**
 *  @author 张杰, 16-03-11 20:03:54
 *
 *  注册账号
 *
 *  @param UserName   姓名
 *  @param Mobile     手机号
 *  @param Password   密码
 *  @param RegionCode 地理位置
 *  @param Referrer   推荐人账号
 */
- (void)RequsetWithRegister:(NSString *)UserName andMobile:(NSString *)Mobile andPassWord:(NSString *)Password andRegionCode:(NSString *)RegionCode andReferrer:(NSString *)Referrer Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock;

//获取位置信息
- (void)RequsetWithZone:(NSString *)type andRegion:(NSString*)Region  Andsuccess:(responseSuccessBlock)succussBlock andfailBlock:(responseErrorBlock)errorblock;
@end
