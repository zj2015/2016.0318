//
//  CC_CountTool.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>

#define coutTool  [[CC_CountTool alloc]init]

typedef void(^tokenBlock)(NSString *token);

@interface CC_CountTool : NSObject


- (void)getAccess_tokenfinishBlock:(tokenBlock)block;

@end
