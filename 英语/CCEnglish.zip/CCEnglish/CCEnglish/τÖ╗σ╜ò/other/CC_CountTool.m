//
//  CC_CountTool.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_CountTool.h"

@interface CC_CountTool()
{
    tokenBlock _finishBlock;
}

@property (nonatomic, strong) NSDateFormatter *fmt;

@end


@implementation CC_CountTool

- (NSDateFormatter *)fmt
{
    if (!_fmt) {
        
        _fmt = [[NSDateFormatter alloc]init];
        [_fmt setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    }
    return _fmt;
}


- (void)getAccess_tokenfinishBlock:(tokenBlock)block;
{
    _finishBlock = block;
    CC_CountTool *tool = [[CC_CountTool alloc]init];
    NSUserDefaults *defuats = [NSUserDefaults standardUserDefaults];
    NSString *date =  [defuats objectForKey:@"expires_in"];
    if (!date) {
        [self requestToken];
        return;
    }
    NSDate *predate = [tool.fmt dateFromString:date];
    BOOL isexpires = [tool compareTime:predate];
    if (isexpires) {
        //过期
        [self requestToken];

    }else{
        NSString *Access_token = [defuats objectForKey:@"access_token"];
        if (Access_token) {
            _finishBlock(Access_token);
        }else{
           [self requestToken];
        }
        //没有过期
    }
    
}



- (BOOL)compareTime:(NSDate *)date
{
    NSDate *new = [NSDate date];
    NSTimeInterval timeBetween = [new timeIntervalSinceDate:date];
    
    if (timeBetween>0) {
        return YES;
    }
    return NO;
}


- (NSString *)requestToken
{
    
    [CC_Requset requesetWithAccess_tokenAndsuccess:^(id result) {
        
        //储存token 和时间
        NSTimeInterval intervarl = [[NSDate date] timeIntervalSince1970];
        NSDictionary *dict = result[@"data"];
        NSUserDefaults *defualts = [NSUserDefaults standardUserDefaults];
        [defualts setObject:[NSString stringWithFormat:@"%f",intervarl] forKey:@"expires_in"];
        [defualts setObject:dict[@"access_token"] forKey:@"access_token"];
        _finishBlock( dict[@"access_token"]);
        
    } andfailBlock:^(id error) {
        _finishBlock(nil);
        
    }];
    return nil;
}

@end
