//
//  CC_RegisterController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_RegisterController.h"
#import "CC_TextField.h"
#import <SMS_SDK/SMSSDK.h>
#import "CC_ListView.h"
#import "CC_Button.h"
#import <SMS_SDK/Extend/SMSSDK+ExtexdMethods.h>

@interface CC_RegisterController()<UIScrollViewDelegate>
{

    CC_TextField *_CurrentEdittextField;
    CC_TextField *_phoneText;
    CC_TextField *_addressText;
    CC_TextField *nameText;
    CC_TextField *_passWordText;
    CC_TextField *_recommenderText;
    NSMutableArray *areaArray;
}
@property (nonatomic, strong) NSMutableArray *btnArray;

@end

@implementation CC_RegisterController

- (NSMutableArray *)btnArray
{
    if (!_btnArray) {
        
        _btnArray = [NSMutableArray array];
    }
    return _btnArray;
}



- (void)viewDidLoad{
    

    [super viewDidLoad];
    areaArray = [NSMutableArray array];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIScrollView *backScrollView   = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    backScrollView.contentSize = CGSizeMake(0, self.view.height+1);
    backScrollView.delegate = self;
    [self.view  addSubview:backScrollView ];
    
    NSNotificationCenter *noticenter = [NSNotificationCenter defaultCenter];
    
    [noticenter addObserver:self selector:@selector(changetheinputframe:) name:@"writtleViewClicked" object:nil];
    //监听键盘的弹出
    //增加监听，当键盘出现或改变时收出消息
    [noticenter addObserver:self selector:@selector(keyboardWillShow:)
                   name:UIKeyboardWillShowNotification
                 object:nil];
    
    //增加监听，当键退出时收出消息
    [noticenter addObserver:self selector:@selector(keyboardWillHide:)
                   name:UIKeyboardWillHideNotification
                 object:nil];

#pragma mark - 背景图
    UIImageView *bgImgView = [[UIImageView alloc] init];
    
    bgImgView.frame = self.view.bounds;
    
    bgImgView.image = [UIImage imageNamed:@"01"];
    
    [backScrollView  addSubview:bgImgView];
    
#pragma mark - 手机号，用户名，密码,地址，验证码，推荐人号码文本输入框
    CC_TextField *usernameText = [[CC_TextField alloc] init];
    nameText = usernameText;
    
    CC_TextField *phoneText = [[CC_TextField alloc] init];
    CC_TextField *verifyText = [[CC_TextField alloc] init];
    CC_TextField *passwordText = [[CC_TextField alloc] init];
    CC_TextField *addressText = [[CC_TextField alloc] init];
    CC_TextField *recommenderText = [[CC_TextField alloc] init];
    
    _recommenderText = recommenderText;
    CGFloat longTextW = 270;
    CGFloat shortTextW = 191;
    CGFloat textH = 40;
    CGFloat textX = (self.view.bounds.size.width - longTextW) * 0.5;
    CGFloat margin = 20;
    
    usernameText.frame = CGRectMake(textX, 70 , longTextW, textH);
    phoneText.frame = CGRectMake(textX, CGRectGetMaxY(usernameText.frame) + margin, longTextW, textH);
    verifyText.frame = CGRectMake(textX, CGRectGetMaxY(phoneText.frame) + margin, shortTextW, textH);
    passwordText.frame = CGRectMake(textX, CGRectGetMaxY(verifyText.frame) + margin, longTextW, textH);
    _passWordText = passwordText;
    addressText.frame = CGRectMake(textX, CGRectGetMaxY(passwordText.frame) + margin , longTextW, textH);
    _addressText = addressText;
    [self initaddressTextField];
    
    recommenderText.frame = CGRectMake(textX, CGRectGetMaxY(addressText.frame) + margin , shortTextW, textH);
    
    usernameText.placeholder = @"   请输入用户名";
    phoneText.placeholder = @"   请输入您的手机号";
    verifyText.placeholder = @"   请输入手机验证码";
    passwordText.placeholder = @"   请输入密码";
//    addressText.placeholder = @"        省      市      县  ";
    recommenderText.placeholder = @"  请填写推荐人号码";
    
    usernameText.text = @"mnm";
    phoneText.text = @"18613319281";
    passwordText.text = @"123456";
    
    
    [usernameText setBackground:[UIImage imageNamed:@"15"]];
    [phoneText setBackground:[UIImage imageNamed:@"15"]];
    _phoneText = phoneText;
    [verifyText setBackground:[UIImage imageNamed:@"16"]];
    [passwordText setBackground:[UIImage imageNamed:@"15"]];
    [addressText setBackground:[UIImage imageNamed:@"15"]];
    [recommenderText setBackground:[UIImage imageNamed:@"16"]];
    
    [backScrollView  addSubview:phoneText];
    [backScrollView  addSubview:usernameText];
    [backScrollView  addSubview:passwordText];
    [backScrollView  addSubview:verifyText];
    [backScrollView  addSubview:addressText];
    [backScrollView  addSubview:recommenderText];
    
#pragma mark - 手机验证码与扫一扫按钮
    UIButton *sendNumberBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *scanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [sendNumberBtn setBackgroundImage:[UIImage imageNamed:@"18"] forState:UIControlStateNormal];
    [scanBtn setBackgroundImage:[UIImage imageNamed:@"17"] forState:UIControlStateNormal];
    
    CGFloat btnW = 80;
    CGFloat btnH = 40;
    CGFloat sendNumberBtnX = verifyText.frame.size.width + verifyText.frame.origin.x + margin;
    CGFloat sendNumberBtnY = verifyText.frame.origin.y;
    
    CGFloat scanBtnX = sendNumberBtnX;
    CGFloat scanBtnY = recommenderText.frame.origin.y;
    
    sendNumberBtn.frame = CGRectMake(sendNumberBtnX, sendNumberBtnY, btnW, btnH);
    scanBtn.frame = CGRectMake(scanBtnX, scanBtnY, btnW, btnH);
    
    [sendNumberBtn addTarget:self action:@selector(sendNumberBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [scanBtn addTarget:self action:@selector(scanBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    [backScrollView  addSubview:sendNumberBtn];
    [backScrollView  addSubview:scanBtn];
    
#pragma mark -  注册并登录按钮
    UIButton *registerAndEnterBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    CGFloat registerAndEnterBtnW = 300;
    CGFloat registerAndEnterBtnH = 50;
    CGFloat registerAndEnterBtnX = (self.view.frame.size.width - registerAndEnterBtnW) * 0.5;
    CGFloat registerAndEnterBtnY = self.view.frame.size.height - registerAndEnterBtnH - margin;
    
    registerAndEnterBtn.frame = CGRectMake(registerAndEnterBtnX, registerAndEnterBtnY, registerAndEnterBtnW, registerAndEnterBtnH);
    
    [registerAndEnterBtn setBackgroundImage:[UIImage imageNamed:@"19"] forState:UIControlStateNormal];
    
    [registerAndEnterBtn addTarget:self action:@selector(registerAndEnterBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    [backScrollView  addSubview:registerAndEnterBtn];
}

- (void)sendNumberBtnClick {
    
    
    //判断手机号
    NSString *code = @"86";
    [self phoneNumberRule];
    for (int i=0; i<areaArray.count; i++) {
        
        NSDictionary* dict1 = [areaArray objectAtIndex:i];
        NSString* code1 = [dict1 valueForKey:@"zone"];
        if ([code1 isEqualToString:code]) {
            NSString* rule1 = [dict1 valueForKey:@"rule"];
            NSPredicate *cate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",rule1];
            BOOL isMatch = [cate evaluateWithObject:_phoneText.text];
            if (!isMatch) {
                [MBProgressHUD showError:@"请输入正确的手机号"];
            }else{
                //获取验证码
                [SMSSDK getVerificationCodeByMethod:SMSGetCodeMethodSMS phoneNumber:_phoneText.text zone:@"86" customIdentifier:nil result:^(NSError *error) {
                    if (error) {
                        [MBProgressHUD showError:@"获取验证码失败,请重新获取"];
                    }else{
                        
                    
                    
                    }
                    
                    
                }];

            
            }

        }
        
    }
    
}





- (void)changetheinputframe:(NSNotification *)note{

    if (_CurrentEdittextField!= note.object) {
        
        [_CurrentEdittextField becomeFirstResponder];
        _CurrentEdittextField = (CC_TextField *)note.object;

    }
    
}

#pragma mark - 键盘弹出
- (void)keyboardWillShow:(NSNotification *)note{

    NSDictionary *userinfo = note.userInfo;
    NSString *time = userinfo[@"UIKeyboardAnimationDurationUserInfoKey"];
    NSValue *theValue  = userinfo[@"UIKeyboardBoundsUserInfoKey"];
    CGFloat theKeyBoardH = [theValue CGRectValue].size.height;
     CGPoint point = [_CurrentEdittextField.superview convertPoint:_CurrentEdittextField.frame.origin toView:self.view];
    CGFloat y1 = point.y+_CurrentEdittextField.height*2;
    CGFloat y2 = (kScreenH - theKeyBoardH);
    if (y1>(y2+20)) {
        
        CGFloat h = -(y1-y2);
        
        [UIView animateWithDuration:time.intValue animations:^{
            self.view.transform = CGAffineTransformMakeTranslation(0, h);
        }];
        
        _CurrentEdittextField = nil;
        
        return;
    }



}


#pragma mark - 键盘退出
- (void)keyboardWillHide:(NSNotification *)note
{
    self.view.transform = CGAffineTransformIdentity;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}


- (void)initaddressTextField
{
    
    for (int i= 0; i<3; i++) {
        
        CC_Button *btn = [[CC_Button alloc]init];
        [_addressText addSubview:btn];
        CGFloat width = _addressText.width/3.0;
        btn.frame = CGRectMake(i*(width-10), 0, width, _addressText.height);
        btn.tag = i+1;
        [btn addTarget:self action:@selector(selectzone:) forControlEvents:UIControlEventTouchUpInside];
        if (i==0) {
            btn.title = @"省";
        }else if (i==1){
            btn.title = @"市";
        }else{
            btn.title = @"县";
        }
        
        [self.btnArray addObject:btn];
     }
}

- (void)selectzone:(CC_Button *)btn
{
    int i = btn.tag;
    if (i==3) {
        CC_Button *citybtn = self.btnArray[1];
        if (citybtn.dict==nil) {
            [MBProgressHUD showError:@"请选择城市"];
            return;
        }
        [self getlistDataWithType:@"3" andregion:citybtn.dict[@"RegionId"] andbtn:btn] ;
       
    }else if (i==2){
    
        CC_Button *prebtn = self.btnArray[0];
        if (prebtn.dict==nil) {
            [MBProgressHUD showError:@"请选择城市"];
            return;
        }
        [self getlistDataWithType:@"3" andregion:prebtn.dict[@"RegionId"] andbtn:btn];
    }
    
    
    if (btn.tag==1) {
        
        [self getlistDataWithType:@"1" andregion:nil andbtn:btn];
        
    }

    

}

- (void)getlistDataWithType:(NSString *)type andregion:(NSString *)region andbtn:(CC_Button *)btn
{
   //网络获取
   [CC_Requset RequsetWithZone:type andRegion:region Andsuccess:^(id result) {
       
       CC_ListView *listView = [[CC_ListView alloc]initwithListArray:result[@"data"] andselectBlock:^(NSDictionary *dict) {
           
           btn.dict = dict;
           
       }];
       listView.frame =CGRectMake(0, 0, 250, 300);
       [listView show];
       
       
   } andfailBlock:^(id error) {
       
   }];
}

- (void)phoneNumberRule
{
    [SMSSDK getCountryZone:^(NSError *error, NSArray *zonesArray) {
        
        if (!error) {
            
            areaArray = [NSMutableArray arrayWithArray:zonesArray];
        }
        
    }];

}


- (void)scanBtnClick {
    
    
}

- (void)registerAndEnterBtnClick {
    
    if (nameText.text.length==0) {
        [MBProgressHUD showError:@"请输入用户名"];
        return;
    }
    if (_phoneText.text.length==0) {
        [MBProgressHUD showError:@"请输入手机号"];
        return;
        
    }
    if (_passWordText.text.length==0) {
        [MBProgressHUD showError:@"请输入密码"];
        return;
        
    }
    NSString *RegionCode = nil;
    for (int i=2 ; i<self.btnArray.count; i--) {
        CC_Button *btn = self.btnArray[i];
        if (btn.dict) {
            RegionCode = btn.dict[@"RegionId"];
            break;
        }
    }
    
    if (!RegionCode)  return;
    
    [CC_Requset RequsetWithRegister:nameText.text andMobile:_phoneText.text andPassWord:_passWordText.text andRegionCode:RegionCode andReferrer:_recommenderText.text Andsuccess:^(id result) {
        
    
        
        
    } andfailBlock:^(id error) {
        
        
        
    }];
    
}



@end
