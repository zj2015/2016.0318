//
//  CC_LoginController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/7.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_identitySelectController.h"
#import "CC_LoginController.h"


@interface CC_identitySelectController ()

@end

@implementation CC_identitySelectController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *bgImgView = [[UIImageView alloc] init];
    
    bgImgView.frame = self.view.bounds;
    
    bgImgView.image = [UIImage imageNamed:@"01"];
    
    [self.view addSubview:bgImgView];
    
    UIImageView *titleImgView = [[UIImageView alloc] init];
    
    UIImage *titleImg = [UIImage imageNamed:@"02"];
    
    CGFloat titleImgViewY = 80;
    CGFloat titleImgViewW = 200;
    CGFloat titleImgViewH = 125;
    CGFloat titleImgViewX = (self.view.bounds.size.width - titleImgViewW) * 0.5;
    
    titleImgView.frame = CGRectMake(titleImgViewX, titleImgViewY, titleImgViewW, titleImgViewH);
    
    titleImgView.image = titleImg;
    
    [self.view addSubview:titleImgView];
    
    UIButton *studentBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *teacherBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [studentBtn setBackgroundImage:[UIImage imageNamed:@"03"] forState:UIControlStateNormal];
    [teacherBtn setBackgroundImage:[UIImage imageNamed:@"04"] forState:UIControlStateNormal];
    
    CGFloat btnW = 150;
    CGFloat btnH = 200;
    CGFloat studentBtnX = (self.view.bounds.size.width - 2 * btnW) / 3;
    CGFloat studentBtnY = (self.view.bounds.size.height - btnH) * 0.5;
    
    CGFloat teacherBtnX = studentBtnX * 2 + btnW;
    CGFloat teacherBtnY = studentBtnY;
    
    studentBtn.frame = CGRectMake(studentBtnX, studentBtnY, btnW, btnH);
    studentBtn.tag = 1001;
    teacherBtn.frame = CGRectMake(teacherBtnX, teacherBtnY, btnW, btnH);
    teacherBtn.tag = 1002;
    
    [studentBtn addTarget:self action:@selector(studentBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [teacherBtn addTarget:self action:@selector(studentBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:studentBtn];
    [self.view addSubview:teacherBtn];
}

- (void)studentBtnClick:(UIButton *)btn {
    
    CC_LoginController *login = [[CC_LoginController alloc]init];
    if (btn.tag==1001) {
        login.type = @"Student-";
    }else{
        login.type = @"Teacher-";

    }
    
    [self.navigationController pushViewController:login animated:YES];
    
    
}




@end
