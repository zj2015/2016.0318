//
//  CC_LoginController.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/8.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_LoginController.h"
#import "CC_RegisterController.h"
#import "CC_TextField.h"
#import "CC_SliderMainController.h"

@interface CC_LoginController()<UIScrollViewDelegate>
{
    CC_TextField *_phoneText;
    CC_TextField *_userNameText;
    CC_TextField *_passWardText;

}

@end

@implementation CC_LoginController

- (void)viewDidLoad
{
    self.view.backgroundColor =[UIColor whiteColor];
    UIScrollView *scrollView = [[UIScrollView alloc]init];
    scrollView.frame = self.view.frame;
    [self.view addSubview:scrollView];
    scrollView.contentSize = CGSizeMake(0, self.view.height+1);
    scrollView.delegate = self;
    
    #pragma mark - 背景图
    UIImageView *bgImgView = [[UIImageView alloc] init];
    bgImgView.userInteractionEnabled = YES;

    bgImgView.frame = self.view.bounds;

    bgImgView.image = [UIImage imageNamed:@"01"];

    [scrollView addSubview:bgImgView];

    #pragma mark - 中间标题图
    UIImageView *titleImgView = [[UIImageView alloc] init];

    UIImage *titleImg = [UIImage imageNamed:@"02"];

    CGFloat titleImgViewY = 80;
    CGFloat titleImgViewW = 200;
    CGFloat titleImgViewH = 125;
    CGFloat titleImgViewX = (self.view.bounds.size.width - titleImgViewW) * 0.5;

    titleImgView.frame = CGRectMake(titleImgViewX, titleImgViewY, titleImgViewW, titleImgViewH);

    titleImgView.image = titleImg;

    [scrollView addSubview:titleImgView];

    UIButton *btn;
    btn.contentEdgeInsets;
    #pragma mark - 手机号，用户名，密码文本输入框
    CC_TextField *phoneText = [[CC_TextField alloc] init];
    phoneText.text = @"18505127387";
    _phoneText = phoneText;
    phoneText.placeholder = @"手机号";
    phoneText.leftView.width = 30;
    CC_TextField *usernameText = [[CC_TextField alloc] init];
    usernameText.text = @"mhh1";
    _userNameText = usernameText;
    usernameText.placeholder = @"用户名";
    usernameText.leftView.width = 30;

    CC_TextField *passwordText = [[CC_TextField alloc] init];
    _passWardText = passwordText;
    passwordText.leftView.width = 30;
    passwordText.placeholder = @"密码";
    passwordText.text = @"123456";


    CGFloat textW = 270;
    CGFloat textH = 40;
    CGFloat textX = (self.view.bounds.size.width - textW) * 0.5;
    CGFloat margin = 20;

    phoneText.frame = CGRectMake(textX, CGRectGetMaxY(titleImgView.frame) + margin, textW, textH);
    usernameText.frame = CGRectMake(textX, CGRectGetMaxY(phoneText.frame) + margin , textW, textH);
    passwordText.frame = CGRectMake(textX, CGRectGetMaxY(usernameText.frame) + margin, textW, textH);

    [phoneText setBackground:[UIImage imageNamed:@"05"]];
    [usernameText setBackground:[UIImage imageNamed:@"08"]];
    [passwordText setBackground:[UIImage imageNamed:@"06"]];

    [scrollView addSubview:phoneText];
    [scrollView addSubview:usernameText];
    [scrollView addSubview:passwordText];

    #pragma mark - 登录与注册按钮
    UIButton *enterBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];

    [enterBtn setBackgroundImage:[UIImage imageNamed:@"09"] forState:UIControlStateNormal];
    [registerBtn setBackgroundImage:[UIImage imageNamed:@"10"] forState:UIControlStateNormal];

    CGFloat btnW = 125;
    CGFloat btnH = 43;
    CGFloat enterBtnX = (self.view.bounds.size.width - 2 * btnW) / 3;
    CGFloat enterBtnY = CGRectGetMaxY(passwordText.frame) + 30;

    CGFloat registerBtnX = enterBtnX * 2 + btnW;
    CGFloat registerBtnY = enterBtnY;

    enterBtn.frame = CGRectMake(enterBtnX, enterBtnY, btnW, btnH);
    registerBtn.frame = CGRectMake(registerBtnX, registerBtnY, btnW, btnH);

    [enterBtn addTarget:self action:@selector(enterBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [registerBtn addTarget:self action:@selector(registerBtnClick) forControlEvents:UIControlEventTouchUpInside];

    [scrollView addSubview:enterBtn];
    [scrollView addSubview:registerBtn];

    #pragma mark - qq登陆，微信登陆按钮
    UIButton *qqBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *weChatBtn = [UIButton buttonWithType:UIButtonTypeCustom];

    [qqBtn setBackgroundImage:[UIImage imageNamed:@"12"] forState:UIControlStateNormal];
    [weChatBtn setBackgroundImage:[UIImage imageNamed:@"11"] forState:UIControlStateNormal];

    CGFloat bottomBtnW = 85;
    CGFloat bottomBtnH = 27;
    CGFloat qqBtnX = (self.view.bounds.size.width - 2 * bottomBtnW) / 3;
    CGFloat qqBtnY = self.view.frame.size.height - bottomBtnH -10;

    CGFloat weChatBtnX = qqBtnX * 2 + bottomBtnW;
    CGFloat weChatBtnY = qqBtnY;

    qqBtn.frame = CGRectMake(qqBtnX, qqBtnY, bottomBtnW, bottomBtnH);
    weChatBtn.frame = CGRectMake(weChatBtnX, weChatBtnY, bottomBtnW, bottomBtnH);

    [qqBtn addTarget:self action:@selector(qqBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [weChatBtn addTarget:self action:@selector(weChatBtnClick) forControlEvents:UIControlEventTouchUpInside];

    [scrollView addSubview:qqBtn];
    [scrollView addSubview:weChatBtn];

}

#pragma mark - 登录按钮点击事件
- (void)enterBtnClick {
    
    if (_phoneText.text.length==0) {
        [MBProgressHUD showError:@"请输入手机号"];
    }
    if (_userNameText.text.length==0) {
        [MBProgressHUD showError:@"请输入用户名"];
    }
    if (_passWardText.text.length==0) {
        
    }
    
    //跳转到app界面
    CC_SliderMainController *sliderVc = [[CC_SliderMainController alloc]init];
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    keyWindow.rootViewController = sliderVc;

    
    [CC_Requset RequestWithLogin:self.type andUserName:_userNameText.text andMobile:_phoneText.text andPassword:_passWardText.text Andsuccess:^(id result) {
        
        //跳转到app界面
        CC_SliderMainController *sliderVc = [[CC_SliderMainController alloc]init];
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        keyWindow.rootViewController = sliderVc;
        
    } andfailBlock:^(id error) {
        
    }];
    
}

#pragma mark - 注册按钮点击事件
- (void)registerBtnClick {
    
    CC_RegisterController *registerVC = [[CC_RegisterController alloc]init];
    [self.navigationController pushViewController:registerVC animated:YES];
    
}

#pragma mark - qq登录按钮点击事件
- (void)qqBtnClick {
    
    
}

#pragma mark - 微信登录按钮点击事件
- (void)weChatBtnClick {
    
    
    
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}


@end
