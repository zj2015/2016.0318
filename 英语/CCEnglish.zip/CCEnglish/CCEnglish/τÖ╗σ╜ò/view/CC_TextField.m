//
//  CC_TextField.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/10.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_TextField.h"

@implementation CC_TextField

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UIView *leftView = [[UIView alloc]init];
        leftView.frame = CGRectMake(0, 0, 10, 25);
        self.leftView = leftView;
        self.leftViewMode = UITextFieldViewModeAlways;
        
        [self addTarget:self action:@selector(textfieldclicked) forControlEvents:UIControlEventEditingDidBegin];
    }
    return self;
}

- (void)textfieldclicked
{
    NSNotificationCenter *noticenter = [NSNotificationCenter defaultCenter];
    
//    [noticenter postNotificationName:@"writtleViewClicked" object:self userInfo:nil];


}



@end
