//
//  CC_ListView.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/11.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^selectListBlock)(NSDictionary *dict);

@interface CC_ListView : UITableView

- initwithListArray:(NSMutableArray *)listArray andselectBlock:(selectListBlock)block;
- (void)show;
- (void)dismiss;


@end
