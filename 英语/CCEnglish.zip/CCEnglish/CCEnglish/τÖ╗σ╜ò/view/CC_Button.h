//
//  CC_Button.h
//  CCEnglish
//
//  Created by 张杰 on 16/3/11.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CC_Button : UIButton

@property (nonatomic, strong) NSDictionary *dict;
@property (nonatomic, copy) NSString *title;

@end
