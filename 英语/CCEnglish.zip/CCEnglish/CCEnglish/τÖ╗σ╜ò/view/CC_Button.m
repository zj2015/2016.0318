//
//  CC_Button.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/11.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_Button.h"

@interface CC_Button()
{
    UILabel *_label;
}

@end

@implementation CC_Button

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UILabel *lable = [[UILabel alloc]init];
        _label = lable;
        lable.textAlignment = NSTextAlignmentRight;
        lable.font = [UIFont systemFontOfSize:14];
        lable.textColor = [UIColor blackColor];
        [self addSubview:lable];

    }
    return self;
}


- (void)setTitle:(NSString *)title
{
    _label.text = title;

}

- (void)setDict:(NSDictionary *)dict
{
    _dict = dict;
    NSString *text = dict[@"Name"];
    _label.text = text;

}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _label.width = self.width;
    _label.height = self.height;

}

@end
