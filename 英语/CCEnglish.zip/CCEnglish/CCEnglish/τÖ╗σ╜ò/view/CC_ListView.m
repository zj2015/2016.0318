//
//  CC_ListView.m
//  CCEnglish
//
//  Created by 张杰 on 16/3/11.
//  Copyright © 2016年 ZJ. All rights reserved.
//

#import "CC_ListView.h"

@interface CC_ListView()<UITableViewDataSource, UITableViewDelegate>
{
    UIButton *_cover;
    NSMutableArray *_listArray;
    selectListBlock _block;
    
}

@end

@implementation CC_ListView

- initwithListArray:(NSMutableArray *)listArray andselectBlock:(selectListBlock)block
{
    if (self == [super init])
    {
        _listArray = listArray;
        if (_listArray==[NSNull null]) {
            _listArray = [NSMutableArray array];
        }
        _block = block;
     
        self.layer.cornerRadius = 15;
        self.clipsToBounds = YES;
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}

- (void)show
{
    
    UIImageView *imageview = [[UIImageView alloc]init];
    UIImage *image = [UIImage imageNamed:@"16"];
    // 左端盖宽度
    NSInteger leftCapWidth = image.size.width * 0.5f;
    // 顶端盖高度
    NSInteger topCapHeight = image.size.height * 0.5f;
    // 重新赋值
    image = [image stretchableImageWithLeftCapWidth:leftCapWidth topCapHeight:topCapHeight];
    imageview.image = image;
    self.backgroundView = imageview;
    
    UIWindow *keyWindow = [[UIApplication sharedApplication].windows lastObject];
    keyWindow.windowLevel = UIWindowLevelNormal;
    
    //遮盖
    UIButton *cover = [[UIButton alloc]init];
    cover.backgroundColor = [UIColor blackColor];
    cover.alpha = .4;
    [cover addTarget:self action:@selector(animatedOut) forControlEvents:UIControlEventTouchUpInside];
    cover.frame = [UIScreen mainScreen].bounds;
    _cover = cover;
    [keyWindow addSubview:cover];
    [keyWindow addSubview:self];
    
    self.center= CGPointMake(kScreenW/2.0, kScreenH/2.0);
    [self animatedIn];
    
}

- (void)dismiss
{
    [self animatedOut];
}


#pragma mark - Animated Mthod
- (void)animatedIn
{
    self.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.alpha = 0;
    [UIView animateWithDuration:.35 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
    self.delegate = self;
    self.dataSource = self;
    [self reloadData];
}



- (void)animatedOut
{
    [UIView animateWithDuration:.35 animations:^{
        [self removeFromSuperview];
        [_cover removeFromSuperview];
        _cover = nil;
    }];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _listArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"CELL";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    NSDictionary *dict = _listArray[indexPath.row];
    cell.textLabel.text = dict[@"Name"];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dict = _listArray[indexPath.row];
    _block(dict);
    [self dismiss];
}
@end
